require(['../common/common'],function(c){
    require(['jquery','base','global','layui','laydate'],function($,api,laydate){

        /**
         * 数据渲染
         */
        var token =  window.localStorage.getItem("token");
        var api ="https://vedio.jiudingfanyi.com";
        //执行一个laydate实例
        laydate.render({
            elem: '#test1' //指定元素
            ,type: 'month',
            trigger:'mouseover',//定义鼠标悬停时弹出控件
            done:function(value,m){//value, date, endDate点击日期、清空、现在、确定均会触发。回调返回三个参数，分别代表：生成的值、日期时间对象、结束的日期时间对象
                // console.log(value);
                // console.log(m.month);
                if(m.month !=12){
                    var startyear = m.year;
                    var startmonth = m.month;
                    var endyear = m.year;
                    var endmonth = m.month +1;
                }else if(m.month ==12){
                    var startyear = m.year;
                    var startmonth = m.month;
                    var endyear = m.year + 1;
                    var endmonth = 01;
                }
                if(startmonth!=12 && startmonth!=11 && startmonth!=10){
                    var startmonth = '0'+startmonth ;
                }
                if(endmonth!=12 && endmonth!=11 && endmonth!=10){
                    var endmonth = '0'+endmonth ;
                }
                var starttime= startyear +'-'+startmonth +'-01';
                var endtime = endyear +'-'+endmonth +'-01';
                var nowtime = startyear +'年'+ startmonth +'月';
                $('.student_head').find('b:nth-of-type(1)').html(nowtime);
                function getUrlParam(key) {
                    // 获取参数
                    var url = window.location.search;
                    // 正则筛选地址栏
                    var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
                    // 匹配目标参数
                    var result = url.substr(1).match(reg);
                    //返回参数值
                    return result ? decodeURIComponent(result[2]) : null;
                }

                function searchFilter(pageindex){
                    var pageNo = getUrlParam('pageIndex');
                    if (!pageNo) {
                        pageNo = pageindex;
                    }
                    $.ajax({
                        url: api + '/api/tuto/student?start='+starttime+'&end='+endtime+'&token=' + token+'&page='+pageNo,
                        type:'GET',
                        dataType:'json',
                        success:function(re){
                            $('.student_head').find('b:nth-of-type(2)').html(re.total);
                            var student=re.data;
                            var html1=template('tpl-student-list-info',student);
                            document.getElementById('student-list-info').innerHTML=html1;
                            //生成分页
                            kkpager.generPageHtml({
                                pno: pageNo,
                                //总页码
                                total : re.last_page,
                                //总数据条数
                                totalRecords : re.total,
                                mode : 'click',
                                click : function(n){
                                    this.selectPage(pageNo);
                                    searchPage(n);
                                    return false;
                                }
                            },true);
                        }
                    });
                }
                //init
                $(function () {
                    searchFilter(1)
                });
                //ajax翻页
                function searchPage(n) {
                    searchFilter(n);
                }

            }
        });

    });
});