/**
 * Created by Administrator on 2018/3/21.
 */
require(['../common/common'],function(c){
    require(['jquery','base','global','layu'],function($,api){

        /**
         * 数据渲染
         */
        /*选项卡*/
        var api ="https://vedio.jiudingfanyi.com";
            var user_id = sessionStorage.getItem('user_id');
                var $ = layui.jquery
                    ,element = layui.element; //Tab的切换功能，切换事件监听等，需要依赖element模块
                    var layer = layui.layer;
                //监听导航点击
                element.on('nav(demo)', function(elem){
                    //console.log(elem)
                    layer.msg(elem.text());
                });

                function GetQueryString(name)
                {
                    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
                    var r = window.location.search.substr(1).match(reg);
                    if(r!=null)return  unescape(r[2]); return null;
                }
                var id = GetQueryString("id");
                sessionStorage.setItem('buy_status','');
                //课程信息
                $.ajax({
                    url: api + '/w/course/'+id,
                    type:'get',
                    dataType:'json',
                    xhrFields: {
                        withCredentials: true
                    },
                    crossDomain: true,
                    success:function(r){
                       // console.log(r);
                        if(r.status==200){
                            $('.course_page_zts .course_img').find('img').attr('src',r.data.cover);
                            $('.course_page_zts .course_page_info_right').find('h2').html(r.data.name);
                            $('.course_page_zts .course_page_info_right p').find('em').html(r.data.point);
                            $('.course_introduction').find('p').html(r.data.profile);
                            var uid = r.data.user_id;
                            //获取作者信息
                            $.ajax({
                                url: api + '/w/user/'+uid,
                                type:'get',
                                dataType:'json',
                                xhrFields: {
                                    withCredentials: true
                                },
                                crossDomain: true,
                                success:function(re){
                                    //console.log(re);
                                    if(re.status==200){
                                        $('.about_author').find('span').html(re.data.name);
                                        $('.about_author').find('p').html(re.data.profile);
                                        $('.personal_profile div').eq(0).find('img').attr('src',re.data.avatar)
                                    }
                                }
                            });
                        }
                    }
                });
                //课程是否购买
                if(user_id && user_id !=''){
                    $.ajax({
                        url: api + '/w/user/'+user_id+'/purchased/course/'+id,
                        type:'get',
                        dataType:'json',
                        xhrFields: {
                            withCredentials: true
                        },
                        crossDomain: true,
                        success:function(re){
                            //console.log(re);
                            if(re.status==200){
                                $('.course_page_info_right div').find('span').show();
                                $('.course_page_info_right div').find('input').hide();
                                sessionStorage.setItem('buy_status',1);
                            }else{
                                $('.course_page_info_right div').find('span').hide();
                                $('.course_page_info_right div').find('input').show();
                                sessionStorage.setItem('buy_status',2);
                            }
                        }
                    });
                }

                $('.buy_btn').on('click',function () {
                    layer.confirm('您是否确定购买本课程？', {
                        btn: ['确定','取消'] //按钮
                    }, function(){
                        $.ajax({
                            url: api + '/w/course/buy/'+id,
                            type:'get',
                            dataType:'json',
                            xhrFields: {
                                withCredentials: true
                            },
                            crossDomain: true,
                            success:function(m){
                                //console.log(m);
                                if(m.status==200){
                                    layer.alert('购买成功');
                                    $('.course_page_info_right div').find('span').show();
                                    $('.course_page_info_right div').find('input').hide();
                                }else{
                                    layer.alert(m.msg);
                                }
                            }
                        });
                    }, function(){
                        layer.msg('好的', {icon: 1});
                    });
                })


                //课程主目录
                $.ajax({
                    url: api + '/api/course/chapter?cid='+id,
                    type:'get',
                    dataType:'json',
                    xhrFields: {
                        withCredentials: true
                    },
                    crossDomain: true,
                    success:function(m){
                        //console.log(m);
                        if(m.status==200){
                            var courses=m.data;
                            var html1=template('tpl-course_catalog-info',courses);
                            document.getElementById('course_catalog-info').innerHTML=html1;
                            if(m.data.length==1){
                                // $('#course_catalog-info li').eq(0).find('dt').addClass('current');
                                $('#course_catalog-info li').eq(0).find('dt').hide();
                                $('#course_catalog-info li').eq(0).find('dd').show();
                                $('#course_catalog-info li').eq(0).find('.icon-jiantouxia').hide();
                                $('#course_catalog-info li').eq(0).find('.icon-jiantoushang').show();
                                var cid = $('#course_catalog-info li').eq(0).find('dt b').html();
                                $.ajax({
                                    url: api + '/api/vedio/chapter?cid='+cid,
                                    type:'get',
                                    dataType:'json',
                                    xhrFields: {
                                        withCredentials: true
                                    },
                                    crossDomain: true,
                                    success:function(n){
                                        //console.log(n);
                                        if(n.status==200){
                                            var catalog=n.data;
                                            var html2=template('tpl-course_catalog-list',catalog);
                                            $('#course_catalog-info li').eq(0).find('div').append(html2);
                                            $('.current_course_info').click(function () {
                                                var current_course_point = $(this).find('b').html();
                                                var buy_status = sessionStorage.getItem('buy_status');
                                                if(!user_id || user_id ==''){
                                                    if(parseInt(current_course_point)!=0){
                                                        layer.msg('观看视频需要先登录或注册');
                                                        return false;
                                                    }else{
                                                        return true;
                                                    }
                                                }else if(parseInt(current_course_point)!=0 && buy_status ==2){
                                                    layer.msg('该视频需要购买所属课程才能观看');
                                                    return false;
                                                }else if(parseInt(current_course_point)!=0 && buy_status ==1){
                                                    return true;
                                                }

                                            })
                                        }
                                    }
                                });
                            }else if(m.data.length > 1){
                                $('.course_catalog').find('dt').click(function () {
                                    var this_dt = $(this);
                                    this_dt.parents('ul').find('dl dd').hide();
                                    this_dt.parents('ul').find('.icon-jiantoushang').hide();
                                    this_dt.parents('ul').find('.icon-jiantouxia').show();
                                    this_dt.parents('ul').find('dl dt').removeClass('current');
                                    this_dt.addClass('current');
                                    this_dt.parent('dl').find('dd').show();
                                    this_dt.find('.icon-jiantouxia').hide();
                                    this_dt.find('.icon-jiantoushang').show();
                                    var cid = this_dt.find('b').html();
                                    //console.log(cid);
                                    //课程次目录
                                    var divinfo =this_dt.parents('dl').find('div').html();
                                    if(divinfo==''){
                                        $.ajax({
                                            url: api + '/api/vedio/chapter?cid='+cid,
                                            type:'get',
                                            dataType:'json',
                                            xhrFields: {
                                                withCredentials: true
                                            },
                                            crossDomain: true,
                                            success:function(n){
                                                //console.log(n);
                                                if(n.status==200){
                                                    var catalog=n.data;
                                                    var html2=template('tpl-course_catalog-list',catalog);
                                                    this_dt.parents('dl').find('div').append(html2);
                                                    $('.current_course_info').click(function () {
                                                        var current_course_point = $(this).find('b').html();
                                                        var buy_status = sessionStorage.getItem('buy_status');
                                                        if(!user_id || user_id ==''){
                                                            if(parseInt(current_course_point)!=0){
                                                                layer.msg('观看视频需要先登录或注册');
                                                                return false;
                                                            }else{
                                                                return true;
                                                            }
                                                        }else if(parseInt(current_course_point)!=0 && buy_status ==2){
                                                            layer.msg('该视频需要购买所属课程才能观看');
                                                            return false;
                                                        }else if(parseInt(current_course_point)!=0 && buy_status ==1){
                                                            return true;
                                                        }

                                                    })
                                                }
                                            }
                                        });
                                    }else{
                                        return false;
                                    }
                                });
                            }
                        }
                    }
                });

    });
});
