if(localStorage.hasOwnProperty("token")){
    if(localStorage.getItem("token")==''){
        window.location = "http://v.jiudingfanyi.com/sub/login";
    }else{
        var token =  window.localStorage.getItem("token");
        var myDate = new Date();
        var mynewDay =myDate.getTime();
        if(localStorage.getItem("expire")*1000 <mynewDay){
            window.location = "http://v.jiudingfanyi.com/sub/login";
        }
    }
}else{
    window.location = "http://v.jiudingfanyi.com/sub/login";
}
