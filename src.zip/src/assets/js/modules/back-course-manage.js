require(['../common/common'],function(c){
    require(['jquery','base','global','layu'],function($,api){

        /**
         * 数据渲染
         */
        var layer = layui.layer;
        var token =  window.localStorage.getItem("token");
        var api ="https://vedio.jiudingfanyi.com";
        function getUrlParam(key) {
            // 获取参数
            var url = window.location.search;
            // 正则筛选地址栏
            var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
            // 匹配目标参数
            var result = url.substr(1).match(reg);
            //返回参数值
            return result ? decodeURIComponent(result[2]) : null;
        }

        function searchFilter(pageindex){
            var pageNo = getUrlParam('pageIndex');
            if (!pageNo) {
                pageNo = pageindex;
            }
            $.ajax({
                url:  api + '/api/tuto/adm/lesson?token=' + token+'&page='+pageNo,
                type:'get',
                dataType:'json',
                success:function(re){
                    //console.log(re);
                    var manage=re.data;
                    $.ajax({
                        type: 'get',
                        url: api + '/api/tuto/tag?token=' + token,
                        dataType: 'json',
                        success: function (m) {
                            var ta = m.data;
                            for(var i=0; i<manage.length; i++){
                                var mana = manage[i].tags.split(',');
                                manage[i].tags='';
                                for(var j=0; j<mana.length;j++){
                                    var tagi = mana[j];
                                    for(var z=0;z<ta.length;z++){
                                        if(tagi==ta[z].id){
                                            manage[i].tags+=" "+ta[z].name;
                                        }
                                    }
                                }
                            }
                            var html1=template('tpl-manage-list-info',manage);
                            document.getElementById('manage-list-info').innerHTML=html1;

                            //生成分页
                            kkpager.generPageHtml({
                                pno: pageNo,
                                //总页码
                                total : re.last_page,
                                //总数据条数
                                totalRecords : re.total,
                                mode : 'click',
                                click : function(n){
                                    this.selectPage(pageNo);
                                    searchPage(n);
                                    return false;
                                }
                            },true);


                            //console.log(manage);
                            $('.undercarriage_btn').click(function () {
                                var  undercarriage = $(this);
                                var id =undercarriage.parents('td').find('.manageid').html();
                                $.ajax({
                                    type: 'post',
                                    url: api + '/api/tuto/lesson/'+id+'?token=' + token,
                                    data:{'_method' :'delete'},
                                    dataType: 'json',
                                    success: function (r) {
                                        //console.log(r);
                                        if(r.status==200){
                                            window.location.reload();
                                        }else{
                                            layer.alert(r.msg)
                                        }
                                    }
                                });
                            })
                            $('.grounding_btn').click(function () {
                                var  grounding = $(this);
                                var id =grounding.parents('td').find('.manageid').html();
                                $.ajax({
                                    type: 'get',
                                    url: api + '/api/tuto/lesson/'+id+'/put?token=' + token,
                                    dataType: 'json',
                                    success: function (r) {
                                        //console.log(r);
                                        if(r.status==200){
                                            window.location.reload();
                                        }else{
                                            layer.alert(r.msg)
                                        }
                                    }
                                });
                            })

                        }
                    });
                }
            });
        }
        //init
        $(function () {
            searchFilter(1)
        });
        //ajax翻页
        function searchPage(n) {
            searchFilter(n);
        }
    });
});