require(['../common/common'],function(c){
    require(['jquery','base','global','layu'],function($,api){

        /**
         * 数据渲染
         */
        var layer = layui.layer;
        var token =  window.localStorage.getItem("token");
        var api ="https://vedio.jiudingfanyi.com";
        function GetQueryString(name)
        {
            var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
            var r = window.location.search.substr(1).match(reg);
            if(r!=null)return  unescape(r[2]); return null;
        }
        var id = GetQueryString("id");
        //实例化编辑器
        var um = UM.getEditor('myEditor');
        //获取编辑器的内容
        //console.log(UM.getEditor('myEditor').getContent())

        //获取不发新课程的信息
           //获取标题
        if(!id){
            $('.audio_info_list').hide();
            $.ajax({
                type: 'get',
                url: api + '/api/tuto/tag?token=' + token,
                dataType: 'json',
                success: function (s) {
                    //console.log(s)
                    if(s.status==200) {

                        var tag = s.data;
                        var htmls = template('tpl-tag-list-info', tag);
                        document.getElementById('tag-list-info').innerHTML = htmls;

                        /*添加专业*/
                        $('.add_btn').click(function () {
                            if($('.keyword').val() == ''){
                                layer.msg('输入框为空')
                            }else{
                                var tagname = $('.keyword').val();
                                $.ajax({
                                    type: 'post',
                                    url: api + '/api/tuto/tag?token=' + token,
                                    data :{
                                        tag:tagname
                                    },
                                    dataType: 'json',
                                    success: function (e) {
                                        //console.log(e)
                                        if(e.status==200){
                                            $('#tag-list-info').append('<label><input name="majorinfo" type="checkbox" value='+e.data.tagId+' />'+$('.keyword').val()+'</label>');
                                        }
                                    }
                                });
                            }
                        });

                        /*删除*/
                            $(document).on('click','.icon-shanchu',function () {
                                $(this).parents('b').remove();
                            })
                        //上传音频
                        $('#upfile').on('change', function(event) {
                            //音频上传
                            var fp = $("#upfile");
                            var lg = fp[0].files.length;
                            var items = fp[0].files;    //音频信息
                            $("#fileTypeError").html('');
                            $('.filename').html('');

                            if (5>=lg > 0) {
                                for (var i = 0; i < lg; i++) {
                                    var fileName = items[i].name; // get file name
                                    var fileSize = items[i].size; // get file size
                                    var fileType = fileName.substr(fileName.length - 4, fileName.length);　　//截取文件类型,如(.mp3)
                                    if (fileSize > 5 * 1024 * 1024) {
                                        $("#fileTypeError").html('录音文件不能大于5M')
                                        return false;
                                    } else if (fileType != '.mp3') {
                                        $("#fileTypeError").html('*上传文件类型错误,支持类型: .mp3');
                                        return false;
                                    } else {
                                        $('.filename').html(fileName);
                                    }
                                }
                            }else if (lg > 5) {
                                layer.msg('最多上传5条录音');
                                return false;
                            }
                        });
                        $('#submit_btn').click(function () {

                            var namenow = $('.title').val();
                            var word_zh0 = $('.word_zh0').val();
                            var word_en0 = $('.word_en0').val();
                            var word_zh1 = $('.word_zh1').val();
                            var word_en1 = $('.word_en1').val();
                            var word_zh2 = $('.word_zh2').val();
                            var word_en2 = $('.word_en2').val();
                            var word_zh3 = $('.word_zh3').val();
                            var word_en3 = $('.word_en3').val();
                            var word_zh4 = $('.word_zh4').val();
                            var word_en4 = $('.word_en4').val();

                            var sentence_en0 = $('.sentence_en0').val();
                            var sentence_ch0 = $('.sentence_ch0').val();
                            var sentence_en1 = $('.sentence_en1').val();
                            var sentence_ch1 = $('.sentence_ch1').val();
                            var sentence_en2 = $('.sentence_en2').val();
                            var sentence_ch2 = $('.sentence_ch2').val();

                            var bijicontent = UM.getEditor('myEditor').getContent();
                            var wordinfo = [];
                            var explanationinfo = [];
                            var sentience_eninfo = [];
                            var sentience_chinfo = [];
                            var chk_value = [];//定义一个数组
                            $('input[name="majorinfo"]:checked').each(function () {//遍历每一个名字为interest的复选框，其中选中的执行函数
                                chk_value.push($(this).val());//将选中的值添加到数组chk_value中
                            });

                            if (namenow == '') {
                                layer.msg('标题不能为空');
                                return false;
                            }
                            if (word_zh0 == '') {
                                layer.msg('第一行单词短语不能为空');
                                return false;
                            } else if (word_en0 == '') {
                                layer.msg('第一行文中词义不能为空');
                                return false;
                            } else if (sentence_en0 == '') {
                                layer.msg('语句第一行英文不能为空');
                                return false;
                            } else if (sentence_ch0 == '') {
                                layer.msg('语句第一行中文不能为空');
                                return false;
                            } else if (bijicontent == '') {
                                layer.msg('练习要求及注意事项不能为空');
                                return false;
                            } else if (chk_value == '') {
                                layer.msg('所属专业未选择');
                                return false;
                            }

                            if (word_zh0 != '') {
                                wordinfo.push(word_zh0);
                            }
                            if (word_zh1 != '') {
                                wordinfo.push(word_zh1);
                            }
                            if (word_zh2 != '') {
                                wordinfo.push(word_zh2);
                            }
                            if (word_zh3 != '') {
                                wordinfo.push(word_zh3);
                            }
                            if (word_zh4 != '') {
                                wordinfo.push(word_zh4);
                            }
                            if (word_en0 != '') {
                                explanationinfo.push(word_en0);
                            }
                            if (word_en1 != '') {
                                explanationinfo.push(word_en1);
                            }
                            if (word_en2 != '') {
                                explanationinfo.push(word_en2);
                            }
                            if (word_en3 != '') {
                                explanationinfo.push(word_en3);
                            }
                            if (word_en4 != '') {
                                explanationinfo.push(word_en4);
                            }
                            if (sentence_en0 != '') {
                                sentience_eninfo.push(sentence_en0);
                            }
                            if (sentence_en1 != '') {
                                sentience_eninfo.push(sentence_en1);
                            }
                            if (sentence_en2 != '') {
                                sentience_eninfo.push(sentence_en2);
                            }
                            if (sentence_ch0 != '') {
                                sentience_chinfo.push(sentence_ch0);
                            }
                            if (sentence_ch1 != '') {
                                sentience_chinfo.push(sentence_ch1);
                            }
                            if (sentence_ch2 != '') {
                                sentience_chinfo.push(sentence_ch2);
                            }
                            var formData1 = new FormData(document.querySelector('#form'));
                            formData1.append('name', namenow);
                            formData1.append('word[]', wordinfo);
                            formData1.append('explanation[]', explanationinfo);
                            formData1.append('sentience_en[]', sentience_eninfo);
                            formData1.append('sentience_ch[]', sentience_chinfo);
                            formData1.append('requirement', bijicontent);
                            formData1.append('tag[]', chk_value);
                            formData1.append("audio[]",$("#upfile").get(0).files[0] );
                            $.ajax({
                                    type: 'post',
                                    url: api + '/api/tuto/lesson?token=' + token,
                                    data: formData1,
                                    cache: false,
                                    processData: false,
                                    contentType: false,
                                    success: function (re) {
                                        //console.log(re);
                                        if (re.status == 200) {
                                            layer.alert('课时提交成功');
                                            window.location.href='http://v.jiudingfanyi.com/teacher/src/back-course-manage.html';
                                        } else {
                                            layer.alert(re.msg);
                                        }
                                    }
                            })

                        })

                    }
                }
            });

        }else{
            //编辑课时
            //获取录音音频
            //上传音频
            $('#upfile').on('change', function(event) {
                //音频上传
                var fp = $("#upfile");
                var lg = fp[0].files.length; // get length
                var items = fp[0].files;    //音频信息
                $("#fileTypeError").html('');
                $('.filename').html('');

                if (5>=lg > 0) {
                    for (var i = 0; i < lg; i++) {
                        var fileName = items[i].name; // get file name
                        var fileSize = items[i].size; // get file size
                        var fileType = fileName.substr(fileName.length - 4, fileName.length);　　//截取文件类型,如(.mp3)
                        if (fileSize > 5 * 1024 * 1024) {
                            $("#fileTypeError").html('录音文件不能大于5M')
                            return false;
                        } else if (fileType != '.mp3') {
                            $("#fileTypeError").html('*上传文件类型错误,支持类型: .mp3');
                            return false;
                        } else {
                            $('.filename').html(fileName);
                            // console.log(items);
                            var formData1 = new FormData(document.querySelector('#form'));
                            formData1.append("audio[]",$("#upfile").get(0).files[0] );
                            // console.log(formData1);
                            var lesson_id =id;
                            $.ajax({
                                type: 'post',
                                url: api + '/api/tuto/lesson/'+lesson_id+'/audio?token=' + token,
                                data: formData1,
                                cache: false,
                                processData: false,
                                contentType: false,
                                success: function (re) {
                                    //console.log(re);
                                    if (re.status == 200) {
                                        layer.alert('音频上传成功');
                                    } else {
                                        layer.alert(re.msg);
                                    }
                                }
                            })
                        }
                    }
                }else if (lg > 5) {
                    layer.msg('最多上传5条录音');
                    return false;
                }
            });

            $.ajax({
                type: 'get',
                url: api + '/api/tuto/lesson/'+id+'?token=' + token,
                dataType: 'json',
                success: function (b) {
                    //console.log(b)
                    if(b.status==200) {
                        var audio1 = b.lesson.audio;
                        //console.log(audio1)
                        var htmla = template('tpl-audio_info_list', audio1);
                        document.getElementById('audio_info_list').innerHTML = htmla;
                        $('#audio_info_list').find('.pc_audio_info').each(function(){
                            var thisaudio = $(this);
                            var menud = 'menu'+$(this).index();
                            thisaudio.find('audio').attr('id',menud)
                            thisaudio.find('div').click(function(){
                                // console.log(menud)
                                var audioid = document.getElementById(menud);
                                event.stopPropagation();
                                if(audioid.paused){
                                    audioid.play();
                                    thisaudio.find('div .bf2').show();
                                    thisaudio.find('div .bf1').hide();
                                    return;
                                }else{
                                    thisaudio.find('div .bf2').hide();
                                    thisaudio.find('div .bf1').show();
                                    audioid.pause();
                                }
                                if(audioid.currentTime ==audioid.duration){
                                    thisaudio.find('div .bf2').hide();
                                    thisaudio.find('div .bf1').show();
                                    audioid.pause();
                                }
                            })
                            thisaudio.find('.shanchu_btn').click(function () {
                                var dele = $(this);
                                var audio_id = dele.parent('.pc_audio_info').find('span').html();
                                var lesson_id =id;
                                $.ajax({
                                    url: api + '/api/tuto/lesson/'+lesson_id+'/audio/'+audio_id+'?token=' + token,
                                    type: 'post',
                                    data: {
                                        _method:'delete',
                                        audio_id:audio_id
                                    },
                                    dataType: "json",
                                    success: function (data) {
                                        //console.log(data)
                                        if(data.status ==200){
                                            dele.parent('.pc_audio_info').remove();
                                            layer.alert('成功删除');
                                        }
                                    }
                                });

                            })
                        })
                    }
                }
            });

            $.ajax({
                type: 'get',
                url: api + '/api/tuto/lesson/'+id+'?token=' + token,
                dataType: 'json',
                success: function (re) {
                    //console.log(re);
                    if(re.status==200){
                        $('.title').val(re.lesson.name);
                        if(re.lesson.word[0]){
                            $('.word_zh0').val(re.lesson.word[0].w);
                            $('.word_en0').val(re.lesson.word[0].e);
                        }
                        if(re.lesson.word[1]){
                            $('.word_zh1').val(re.lesson.word[1].w);
                            $('.word_en1').val(re.lesson.word[1].e);
                        }
                        if(re.lesson.word[2]){
                            $('.word_zh2').val(re.lesson.word[2].w);
                            $('.word_en2').val(re.lesson.word[2].e);
                        }
                        if(re.lesson.word[3]){
                            $('.word_zh3').val(re.lesson.word[3].w);
                            $('.word_en3').val(re.lesson.word[3].e);
                        }
                        if(re.lesson.word[4]){
                            $('.word_zh4').val(re.lesson.word[4].w);
                            $('.word_en4').val(re.lesson.word[4].e);
                        }
                        if(re.lesson.sentience[0]){
                            $('.sentence_en0').val(re.lesson.sentience[0].en);
                            $('.sentence_ch0').val(re.lesson.sentience[0].ch);
                        }
                        if(re.lesson.sentience[1]){
                            $('.sentence_en1').val(re.lesson.sentience[1].en);
                            $('.sentence_ch1').val(re.lesson.sentience[1].ch);
                        }
                        if(re.lesson.sentience[2]){
                            $('.sentence_en2').val(re.lesson.sentience[2].en);
                            $('.sentence_ch2').val(re.lesson.sentience[2].ch);
                        }
                        //把获取的内容填到编辑器中
                        um.ready(function(){
                            um.setContent(re.lesson.requirement);
                        });
                        $.ajax({
                            type: 'get',
                            url: api + '/api/tuto/tag?token=' + token,
                            dataType: 'json',
                            success: function (d) {
                                //console.log(d);
                                if(d.status==200){
                                    var tag=d.data;
                                    var html1=template('tpl-tag-list-info',tag);
                                    document.getElementById('tag-list-info').innerHTML=html1;
                                    /*添加专业*/
                                    $('.add_btn').click(function () {
                                        //console.log($('.keyword').val());
                                        if($('.keyword').val() == ''){
                                            layer.msg('输入框为空')
                                        }else{
                                            var tagname = $('.keyword').val();
                                            $.ajax({
                                                type: 'post',
                                                url: api + '/api/tuto/tag?token=' + token,
                                                data :{
                                                    tag:tagname
                                                },
                                                dataType: 'json',
                                                success: function (e) {
                                                    //console.log(e)
                                                    if(e.status==200){
                                                        $('#tag-list-info').append('<label><input name="majorinfo" type="checkbox" value='+e.data.tagId+' />'+$('.keyword').val()+'</label>');
                                                    }
                                                }
                                            });
                                        }
                                    });
                                    $('.submit_btn').click(function () {
                                        var name1 = $('.title').val();
                                        var word_zh0 = $('.word_zh0').val();
                                        var word_en0 = $('.word_en0').val();
                                        var word_zh1 = $('.word_zh1').val();
                                        var word_en1 = $('.word_en1').val();
                                        var word_zh2 = $('.word_zh2').val();
                                        var word_en2 = $('.word_en2').val();
                                        var word_zh3 = $('.word_zh3').val();
                                        var word_en3 = $('.word_en3').val();
                                        var word_zh4 = $('.word_zh4').val();
                                        var word_en4 = $('.word_en4').val();

                                        var sentence_en0 =$('.sentence_en0').val();
                                        var sentence_ch0 =$('.sentence_ch0').val();
                                        var sentence_en1 =$('.sentence_en1').val();
                                        var sentence_ch1 =$('.sentence_ch1').val();
                                        var sentence_en2 =$('.sentence_en2').val();
                                        var sentence_ch2 =$('.sentence_ch2').val();

                                        var bijicontent = UM.getEditor('myEditor').getContent();
                                        var wordinfo = [];
                                        var explanationinfo = [];
                                        var sentience_eninfo= [];
                                        var sentience_chinfo =[];
                                        if(word_zh0 !=''){
                                            wordinfo.push(word_zh0);
                                        }
                                        if(word_zh1 !=''){
                                            wordinfo.push(word_zh1);
                                        }
                                        if(word_zh2 !=''){
                                            wordinfo.push(word_zh2);
                                        }
                                        if(word_zh3 !=''){
                                            wordinfo.push(word_zh3);
                                        }
                                        if(word_zh4 !=''){
                                            wordinfo.push(word_zh4);
                                        }
                                        if(word_en0 !=''){
                                            explanationinfo.push(word_en0);
                                        }
                                        if(word_en1 !=''){
                                            explanationinfo.push(word_en1);
                                        }
                                        if(word_en2 !=''){
                                            explanationinfo.push(word_en2);
                                        }
                                        if(word_en3 !=''){
                                            explanationinfo.push(word_en3);
                                        }
                                        if(word_en4 !=''){
                                            explanationinfo.push(word_en4);
                                        }
                                        if(sentence_en0 !=''){
                                            sentience_eninfo.push(sentence_en0);
                                        }
                                        if(sentence_en1 !=''){
                                            sentience_eninfo.push(sentence_en1);
                                        }
                                        if(sentence_en2 !=''){
                                            sentience_eninfo.push(sentence_en2);
                                        }
                                        if(sentence_ch0 !=''){
                                            sentience_chinfo.push(sentence_ch0);
                                        }
                                        if(sentence_ch1 !=''){
                                            sentience_chinfo.push(sentence_ch1);
                                        }
                                        if(sentence_ch2 !=''){
                                            sentience_chinfo.push(sentence_ch2);
                                        }
                                        var chk_value =[];//定义一个数组
                                        $('input[name="majorinfo"]:checked').each(function(){//遍历每一个名字为interest的复选框，其中选中的执行函数
                                            chk_value.push($(this).val());//将选中的值添加到数组chk_value中
                                        });
                                        $.ajax({
                                            type: 'post',
                                            url: api + '/api/tuto/lesson/'+id+'?token=' + token,
                                            data: {
                                                _method :'put',
                                                name:name1,
                                                word:wordinfo,
                                                explanation:explanationinfo,
                                                sentience_en:sentience_eninfo,
                                                sentience_ch:sentience_chinfo,
                                                requirement:bijicontent,
                                                tag :chk_value
                                            },
                                            dataType: 'json',
                                            success: function (m) {
                                                //console.log(m);
                                                if(m.status==200){
                                                    layer.alert('编辑提交成功');
                                                    window.location.href='http://v.jiudingfanyi.com/teacher/src/back-course-manage.html';
                                                }else{
                                                    layer.alert(m.msg);
                                                }
                                            }
                                        });

                                    })
                                }else{
                                    layer.alert(d.msg);
                                }
                            }
                        });
                    }else{
                        layer.alert(re.msg);
                    }
                }
            });
        }
    });
});