define(function(){
	return "https://vedio.jiudingfanyi.com";
});
