require(['../common/common'],function(c){
    require(['jquery','base','template','global','laydate'],function($,template,api,laydate){

        /**
         * 数据渲染
         */
        var api ="https://vedio.jiudingfanyi.com";
        //执行一个laydate实例
        laydate.render({
            elem: '#test1' //指定元素
            ,type: 'month'
        });

    });
});