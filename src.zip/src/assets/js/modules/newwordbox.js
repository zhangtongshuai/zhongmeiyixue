require(['../common/common'],function(c){
    require(['jquery','base','global','layu'],function($,api){

        /**
         * 数据渲染
         */
        var laypage = layui.laypage
            ,layer = layui.layer;
        var api ="https://vedio.jiudingfanyi.com";
        var user_id = sessionStorage.getItem('user_id');
        if(!user_id || user_id ==''){
            $('.newwordbox_details').hide();
            layer.confirm('您还没有登录，登录后才能查看！', {
                btn: ['登录','取消'] //按钮
            }, function(){
                var current_url = window.location.href;
                sessionStorage.setItem('current_url',current_url);
                window.location.href='https://open.weixin.qq.com/connect/qrconnect?appid=wx7898df574edbcfd1&redirect_uri=http%3a%2f%2fwww.zhongmeiyixue.com&response_type=code&scope=snsapi_login&state=STATE&connect_redirect=1#wechat_redirect';
            }, function(){
                // layer.msg('好的', {icon: 1});
            });
            return false;
        }

            $.ajax({
                url: api + '/w/user/'+user_id+'/vocabulary' ,
                type:'get',
                dataType:'json',
                xhrFields: {
                    withCredentials: true
                },
                crossDomain: true,
                success:function(re){
                   // console.log(re);
                    if(re.status==200){
                        laypage.render({
                            elem: 'demo6'
                            ,count: re.total
                            ,layout: ['prev', 'next']
                            ,jump: function(obj, first){
                                if(!first){
                                    layer.msg('第 '+ obj.curr +' 页');
                                }
                                $.ajax({
                                    url: api + '/w/user/'+user_id+'/vocabulary?page='+obj.curr,
                                    type:'get',
                                    dataType:'json',
                                    xhrFields: {
                                        withCredentials: true
                                    },
                                    crossDomain: true,
                                    success:function(c) {
                                        //console.log(c);
                                        if (c.status == 200) {
                                            var courses = c.data;
                                            var html1 = template('tpl-word-list-info', courses);
                                            document.getElementById('word-list-info').innerHTML = html1;

                                            if(courses.length ==0){
                                                return false;
                                            }
                                            //默认第一个单词释义
                                            var mrword = $('#word-list-info').find('li:nth-of-type(1)').text().toLowerCase();
                                            $('.newwordbox_details').find('h4').html(mrword);
                                            $('.newwordbox_details .audio_info').find('span').html('');
                                            $('.newwordbox_details .audio_info').find('audio').removeAttr('src');
                                            $('.newwordbox_details .word_meaning').find('span').html('');
                                            $('#bilingualism-list-info').find('p').html('');
                                            $.ajax({
                                                type: 'get',
                                                url: api + '/api/vocab/detail/'+mrword,
                                                dataType: 'json',
                                                success: function (m) {
                                                   // console.log(m);
                                                    if(m.pos ==null){
                                                        alert('未查询到释义')
                                                        return false;
                                                    }
                                                    if(Array.isArray(m.ps)){
                                                        var ysfy = '英['+m.ps[0]+']';
                                                        var msfy = '美['+m.ps[1]+']';
                                                        var ysyp = m.pron[0];
                                                        var msyp = m.pron[1];
                                                        $('.newwordbox_details .audio_info').find('span:nth-of-type(1)').html(ysfy);
                                                        $('.newwordbox_details .audio_info').find('span:nth-of-type(2)').html(msfy);
                                                        $('.newwordbox_details .audio_info').find('audio').attr('src',ysyp);
                                                        $('.newwordbox_details .audio_info').find('audio').attr('src',msyp);
                                                        $('.newwordbox_details .audio_info').find('img').show();
                                                    }else {
                                                        var ysfy = '英['+m.ps+']';
                                                        var ysyp = m.pron;
                                                        $('.newwordbox_details .audio_info').find('span:nth-of-type(1)').html(ysfy);
                                                        $('.newwordbox_details .audio_info').find('audio').attr('src',ysyp);
                                                        $('.newwordbox_details .audio_info').find('img:nth-of-type(2)').hide();
                                                    }
                                                    if(Array.isArray(m.pos)){
                                                        var cx0 = m.pos[0];
                                                        var cx1 = m.pos[1];
                                                        var cx2 = m.pos[2];
                                                        var sy0 = m.acceptation[0];
                                                        var sy1 = m.acceptation[1];
                                                        var sy2 = m.acceptation[2];
                                                        $('.newwordbox_details .word_meaning').eq(0).find('span').eq(0).html(cx0);
                                                        $('.newwordbox_details .word_meaning').eq(0).find('span').eq(1).html(sy0);
                                                        $('.newwordbox_details .word_meaning').eq(1).find('span').eq(0).html(cx1);
                                                        $('.newwordbox_details .word_meaning').eq(1).find('span').eq(1).html(sy1);
                                                        $('.newwordbox_details .word_meaning').eq(2).find('span').eq(0).html(cx2);
                                                        $('.newwordbox_details .word_meaning').eq(2).find('span').eq(1).html(sy2);
                                                    }else{
                                                        var cx0 = m.pos;
                                                        var sy0 = m.acceptation;
                                                        $('.newwordbox_details .word_meaning').eq(0).find('span').eq(0).html(cx0);
                                                        $('.newwordbox_details .word_meaning').eq(0).find('span').eq(1).html(sy0);
                                                    }

                                                    var bilingualism=m.sent;
                                                    var html2=template('tpl-bilingualism-list-info',bilingualism);
                                                    document.getElementById('bilingualism-list-info').innerHTML=html2;

                                                }
                                            });
                                            //单词释义
                                            $('#word-list-info').find('li').click(function () {
                                                var word =$(this).text().toLowerCase();
                                                $('.newwordbox_details').find('h4').html(word);
                                                $('.newwordbox_details .audio_info').find('span').html('');
                                                $('.newwordbox_details .audio_info').find('audio').removeAttr('src');
                                                $('.newwordbox_details .word_meaning').find('span').html('');
                                                $('#bilingualism-list-info').find('p').html('');
                                                $.ajax({
                                                    type: 'get',
                                                    url: api + '/api/vocab/detail/'+word,
                                                    dataType: 'json',
                                                    success: function (m) {
                                                       // console.log(m);
                                                        if(m.pos ==null){
                                                            alert('未查询到释义')
                                                            return false;
                                                        }
                                                        if(Array.isArray(m.ps)){
                                                            var ysfy = '英['+m.ps[0]+']';
                                                            var msfy = '美['+m.ps[1]+']';
                                                            var ysyp = m.pron[0];
                                                            var msyp = m.pron[1];
                                                            $('.newwordbox_details .audio_info').find('span:nth-of-type(1)').html(ysfy);
                                                            $('.newwordbox_details .audio_info').find('span:nth-of-type(2)').html(msfy);
                                                            $('.newwordbox_details .audio_info').find('audio').attr('src',ysyp);
                                                            $('.newwordbox_details .audio_info').find('audio').attr('src',msyp);
                                                            $('.newwordbox_details .audio_info').find('img').show();
                                                        }else {
                                                            var ysfy = '英['+m.ps+']';
                                                            var ysyp = m.pron;
                                                            $('.newwordbox_details .audio_info').find('span:nth-of-type(1)').html(ysfy);
                                                            $('.newwordbox_details .audio_info').find('audio').attr('src',ysyp);
                                                            $('.newwordbox_details .audio_info').find('img:nth-of-type(2)').hide();
                                                        }
                                                        if(Array.isArray(m.pos)){
                                                            var cx0 = m.pos[0];
                                                            var cx1 = m.pos[1];
                                                            var cx2 = m.pos[2];
                                                            var sy0 = m.acceptation[0];
                                                            var sy1 = m.acceptation[1];
                                                            var sy2 = m.acceptation[2];
                                                            $('.newwordbox_details .word_meaning').eq(0).find('span').eq(0).html(cx0);
                                                            $('.newwordbox_details .word_meaning').eq(0).find('span').eq(1).html(sy0);
                                                            $('.newwordbox_details .word_meaning').eq(1).find('span').eq(0).html(cx1);
                                                            $('.newwordbox_details .word_meaning').eq(1).find('span').eq(1).html(sy1);
                                                            $('.newwordbox_details .word_meaning').eq(2).find('span').eq(0).html(cx2);
                                                            $('.newwordbox_details .word_meaning').eq(2).find('span').eq(1).html(sy2);
                                                        }else{
                                                            var cx0 = m.pos;
                                                            var sy0 = m.acceptation;
                                                            $('.newwordbox_details .word_meaning').eq(0).find('span').eq(0).html(cx0);
                                                            $('.newwordbox_details .word_meaning').eq(0).find('span').eq(1).html(sy0);
                                                        }

                                                        var bilingualism=m.sent;
                                                        var html2=template('tpl-bilingualism-list-info',bilingualism);
                                                        document.getElementById('bilingualism-list-info').innerHTML=html2;

                                                    }
                                                });

                                            })

                                        }
                                    }
                                });
                            }
                        });

                    }
                    if(re.data==''){
                        $('#demo6').hide();
                    }

                }
            });

    });
});