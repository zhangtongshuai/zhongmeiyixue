require(['../common/common'],function(c){
    require(['jquery','base','global','layu'],function($,api){

        /**
         * 数据渲染
         */
        var layer = layui.layer;
        var api ="https://vedio.jiudingfanyi.com";
        var user_id = sessionStorage.getItem('user_id');

        if(!user_id || user_id ==''){
            layer.confirm('您还没有登录，登录后才能查看！', {
                btn: ['登录','取消'] //按钮
            }, function(){
                var current_url = window.location.href;
                sessionStorage.setItem('current_url',current_url);
                window.location.href='https://open.weixin.qq.com/connect/qrconnect?appid=wx7898df574edbcfd1&redirect_uri=http%3a%2f%2fwww.zhongmeiyixue.com&response_type=code&scope=snsapi_login&state=STATE&connect_redirect=1#wechat_redirect';
            }, function(){
                // layer.msg('好的', {icon: 1});
            });
            return false;
        }
        //分页
        function getUrlParam(key) {
            // 获取参数
            var url = window.location.search;
            // 正则筛选地址栏
            var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
            // 匹配目标参数
            var result = url.substr(1).match(reg);
            //返回参数值
            return result ? decodeURIComponent(result[2]) : null;
        }

        function searchFilter(pageindex){
            var pageNo = getUrlParam('pageIndex');
            if (!pageNo) {
                pageNo = pageindex;
            }

            $.ajax({
                url: api + '/w/user/'+user_id+'/purchased/course?page='+pageNo ,
                type:'get',
                dataType:'json',
                xhrFields: {
                    withCredentials: true
                },
                crossDomain: true,
                success:function(re){
                   // console.log(re);
                    var courses=re.data;
                    for(var i=0;i<courses.length;i++){
                        var date = new Date(courses[i].created_at);
                        var time1 = date.getTime();
                        //console.log(time1);
                        function timestampToTime(timestamp) {
                            var date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
                            Y = date.getFullYear() + '-';
                            M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
                            D = date.getDate() + ' ';
                            courses[i].created_at = Y+M+D;
                        }
                        timestampToTime(time1);
                    }
                    var html1=template('tpl-video_courses-list-info',courses);
                    document.getElementById('video_courses-list-info').innerHTML=html1;
                    if(re.data==''){
                        $('#kkpager').hide();
                    }
                    // var tot = Math.ceil(re.total/re.per_page);
                    //生成分页
                    kkpager.generPageHtml({
                        pno: pageNo,
                        //总页码
                        total : re.last_page,
                        //总数据条数
                        totalRecords : re.total,
                        mode : 'click',
                        click : function(n){
                            this.selectPage(pageNo);
                            searchPage(n);
                            return false;
                        }
                    },true);
                }
            });
        }
        //init
        $(function () {
            searchFilter(1)
        });
        //ajax翻页
        function searchPage(n) {
            searchFilter(n);
        }


    });
});