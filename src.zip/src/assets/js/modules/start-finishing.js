require(['../common/common'],function(c){
    require(['jquery','base','global','jquerysticky'],function($,api){

        /**
         * 数据渲染
         */
        /*视频播放器*/
        var player = null;
         source = playURL;
        var cover ='';  //填入每个视频单独的封面
        $(function(){
            player = createPlayer(source,cover);
            player.on('ready',function(){
                //console.log('ready可以调用播放器的方法了');
            });

            player.on('play',function(){
                //console.log('开始播放(play)');
            });

            player.on('pause',function(){
                //console.log('暂停播放(pause)');
            });

            $('.change').on('click',function(){
                var source = $('.source').val();
                var playAuth = $('.playauth').val();
                player = createPlayer(source,playAuth);
            })

            $('.submit').on('click',function(){
                var source = $('.source').val();
                var playAuth = $('.playauth').val();
                if(!source)
                {
                    return;
                }
                if(source.indexOf('//')!=-1)
                {
                    player.loadByUrl(source);
                }
                else if(playAuth)
                {
                    if(player.replayByVidAndPlayAuth)
                    {
                        player.replayByVidAndPlayAuth(source, playAuth);
                    }
                    else
                    {
                        player = createPlayer(source,playAuth);
                    }
                }
            })
        });
        function createPlayer(source, playauth)
        {
            if(player)
            {
                player.dispose();
                $('#J_prismPlayer').empty();
                player = null;
            }
            var vid = source;
            if(!source && !playauth)
            {
                source = '';
                vid = "";
                playauth = "";
            }
            else if(source.indexOf('//')!=-1)
            {
                playAuth = "";
            }
            else if(playauth)
            {
                source = "";
            }
            var option = {
                id: "J_prismPlayer",
                autoplay: false,
                isLive:false,
                playsinline:true,
                width:"840px",
                height:"355px",
                controlBarVisibility:"click",
                useH5Prism:false, //启用H5播放器
                useFlashPrism:true,
                source:source,
                vid:vid,
                playauth:playauth,
                cover:cover
            };

            return new Aliplayer(option);
        }

        /*选项卡*/
        $(function(){
            /*导航置顶*/
            $(".collate_video").sticky({ topSpacing: 0 });
        });
        /*编辑*/
        $('.edit_btn').click(function () {
            var edit = $(this);
            edit.parents('tr').find('.hold_btn').css({'display':'block'});
            edit.parents('tr').find('.edit_btn').css({'display':'none'});
            edit.parents('tr').find('textarea').css({'display':'block'});
        })
        /*保存*/
        $('.hold_btn').click(function () {
            var hold = $(this);
            hold.parents('tr').find('.edit_btn').css({'display':'block'});
            hold.parents('tr').find('.hold_btn').css({'display':'none'});
            hold.parents('tr').find('textarea').css({'display':'none'});
        })

    });
});