/**
 * Created by Administrator on 2018/3/20.
 */
require(['../common/common'],function(c){
    require(['jquery','base','global','layu'],function($,api){

        /**
         * 数据渲染
         */

        var layer = layui.layer;
        var api ="https://vedio.jiudingfanyi.com";
        var url;
        function getQueryString(name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
            var r = window.location.search.substr(1).match(reg);
            if (r != null) return unescape(r[2]); return null;
        }

        var code = getQueryString("code");
        //console.log(code)
        if(code){
            $.ajax({
                async: false,
                url: api + "/w/login",
                type: "get",
                //下面几行是jsoup，如果去掉下面几行的注释，后端对应的返回结果也要去掉注释
                dataType: 'json',
                data: {code:code}, //传递本页面获取的code到后台，以便后台获取openid
                timeout:5000,
                xhrFields: {
                    withCredentials: true
                },
                crossDomain: true,
                success: function (h) {
                    //console.log(h)
                    if(h.status ==200){
                        sessionStorage.setItem('user_id',h.data.user.id);
                        sessionStorage.setItem('user_name',h.data.user.name);
                        sessionStorage.setItem('user_avatar',h.data.user.avatar);
                        sessionStorage.setItem('csrf_token',h.data.csrf_token);
                        var current_url = sessionStorage.getItem('current_url');
                        window.location.href=current_url;
                    }
                }
            });
        }


        //banner左侧内容栏
        $(function(){
            var thisTime;
            //鼠标离开左侧内容栏
            $('.cat_wrap .cat_list .float').mouseleave(function(even){
                thisTime = setTimeout(thisMouseOut,1000);
            });
            //鼠标点击左侧内容栏   滑动出弹层
            $('.cat_wrap .cat_list .float').mouseenter(function(){
                $(this).addClass("active").siblings().removeClass("active");
                clearTimeout(thisTime);
                var thisUB = $('.cat_wrap .cat_list .float').index($(this));
                if($.trim($('.cat_subcont .cat_sublist').eq(thisUB).html()) != ""){
                    $('.cat_subcont').addClass('active');
                    $('.cat_sublist').hide();
                    $('.cat_sublist').eq(thisUB).show();
                }else{
                    $('.cat_subcont').removeClass('active');
                }
            });
            //函数——执行鼠标离开左侧内容栏的动作
            function thisMouseOut(){
                $('.cat_subcont').removeClass('active');
                $('.cat_wrap .cat_list .float').removeClass('active');
            }
            $('.cat_subcont').mouseenter(function(){
                clearTimeout(thisTime);
                $('.cat_subcont').addClass('active');
            });
            $('.cat_subcont').mouseleave(function(){
                $('.cat_subcont').removeClass('active');
                $('.cat_wrap .cat_list .float').removeClass('active');
            });
        });
        //分类
        $.ajax({
            type: 'get',
            url: api + '/api/cate',
            dataType: 'json',
            success: function (re) {
               // console.log(re);
                if(re.status ==200){
                    //var assortment=re.data;
                    sessionStorage.setItem('cate_id','');
                    $('.assortment1').find('li span').html(re.data[0].id);
                    $('.assortment1').find('li b').html(re.data[0].name);
                    $('.assortment2').find('li span').html(re.data[1].id);
                    $('.assortment2').find('li b').html(re.data[1].name);
                    $('.assortment3').find('li span').html(re.data[2].id);
                    $('.assortment3').find('li b').html(re.data[2].name);
                    $('.assortment4').find('li span').html(re.data[3].id);
                    $('.assortment4').find('li b').html(re.data[3].name);
                    $('.assortment5').find('li span').html(re.data[4].id);
                    $('.assortment5').find('li b').html(re.data[4].name);
                    $('.cat_sublist').eq(0).find('h3').click(function () {
                        var cate_id = $(this).find('span').html();
                        sessionStorage.setItem('cate_id',cate_id);
                        sessionStorage.setItem('menu3','');
                        sessionStorage.setItem('menu2','');
                        sessionStorage.setItem('menu1','');
                        window.location.reload();
                    });
                    $('.cat_sublist').eq(0).find('ul li').click(function () {
                        var cate_id = $(this).find('span').html();
                        sessionStorage.setItem('cate_id',cate_id);
                        sessionStorage.setItem('menu3','');
                        sessionStorage.setItem('menu2','');
                        sessionStorage.setItem('menu1','');
                        window.location.reload();
                    });
                    var id1 = $('.assortment1').find('li span').html();
                    $.ajax({
                        type: 'get',
                        url: api + '/api/cate/'+id1,
                        dataType: 'json',
                        success: function (m) {
                            //console.log(m);
                            if(m.status ==200){
                                var assortment1=m.data;
                                var html1=template('tpl-assortment1-list-info',assortment1);
                                document.getElementById('assortment1-list-info').innerHTML=html1;
                                $('.cat_sublist').eq(1).find('h3').click(function () {
                                    var cate_id = $(this).find('span').html();
                                    sessionStorage.setItem('cate_id',cate_id);
                                    var menu2 =  $(this).find('a').html();
                                    var menu1 = $(this).parents('.cat_sublist').find('.main_menu').html();
                                    sessionStorage.setItem('menu3','');
                                    sessionStorage.setItem('menu2',menu2);
                                    sessionStorage.setItem('menu1',menu1);
                                    sessionStorage.setItem('level',2);
                                    window.location.reload();
                                });
                                $('.cat_sublist').eq(1).find('ul li').click(function () {
                                    var cate_id = $(this).find('span').html();
                                    sessionStorage.setItem('cate_id',cate_id);
                                    var menu3 = $(this).find('a').html();
                                    var menu2 = $(this).parents('.fore_list').find('h3 a').html();
                                    var menu1 = $(this).parents('.cat_sublist').find('.main_menu').html();
                                    sessionStorage.setItem('menu3',menu3);
                                    sessionStorage.setItem('menu2',menu2);
                                    sessionStorage.setItem('menu1',menu1);
                                    sessionStorage.setItem('level',3);
                                    window.location.reload();
                                });
                            }
                        }
                    });
                    var id2 = $('.assortment2').find('li span').html();
                    $.ajax({
                        type: 'get',
                        url: api + '/api/cate/'+id2,
                        dataType: 'json',
                        success: function (m) {
                            //console.log(m);
                            if(m.status ==200){
                                var assortment2=m.data;
                                var html1=template('tpl-assortment2-list-info',assortment2);
                                document.getElementById('assortment2-list-info').innerHTML=html1;
                                $('.cat_sublist').eq(2).find('h3').click(function () {
                                    var cate_id = $(this).find('span').html();
                                    sessionStorage.setItem('cate_id',cate_id);
                                    var menu2 =  $(this).find('a').html();
                                    var menu1 = $(this).parents('.cat_sublist').find('.main_menu').html();
                                    sessionStorage.setItem('menu3','');
                                    sessionStorage.setItem('menu2',menu2);
                                    sessionStorage.setItem('menu1',menu1);
                                    sessionStorage.setItem('level',2);
                                    window.location.reload();
                                });
                                $('.cat_sublist').eq(2).find('ul li').click(function () {
                                    var cate_id = $(this).find('span').html();
                                    sessionStorage.setItem('cate_id',cate_id);
                                    var menu3 = $(this).find('a').html();
                                    var menu2 = $(this).parents('.fore_list').find('h3 a').html();
                                    var menu1 = $(this).parents('.cat_sublist').find('.main_menu').html();
                                    sessionStorage.setItem('menu3',menu3);
                                    sessionStorage.setItem('menu2',menu2);
                                    sessionStorage.setItem('menu1',menu1);
                                    sessionStorage.setItem('level',3);
                                    window.location.reload();
                                });
                            }
                        }
                    });
                    var id3 = $('.assortment3').find('li span').html();
                    $.ajax({
                        type: 'get',
                        url: api + '/api/cate/'+id3,
                        dataType: 'json',
                        success: function (m) {
                            //console.log(m);
                            if(m.status ==200){
                                var assortment3=m.data;
                                var html1=template('tpl-assortment3-list-info',assortment3);
                                document.getElementById('assortment3-list-info').innerHTML=html1;
                                $('.cat_sublist').eq(3).find('h3').click(function () {
                                    var cate_id = $(this).find('span').html();
                                    sessionStorage.setItem('cate_id',cate_id);
                                    var menu2 =  $(this).find('a').html();
                                    var menu1 = $(this).parents('.cat_sublist').find('.main_menu').html();
                                    sessionStorage.setItem('menu3','');
                                    sessionStorage.setItem('menu2',menu2);
                                    sessionStorage.setItem('menu1',menu1);
                                    sessionStorage.setItem('level',2);
                                    window.location.reload();
                                });
                                $('.cat_sublist').eq(3).find('ul li').click(function () {
                                    var cate_id = $(this).find('span').html();
                                    sessionStorage.setItem('cate_id',cate_id);
                                    var menu3 = $(this).find('a').html();
                                    var menu2 = $(this).parents('.fore_list').find('h3 a').html();
                                    var menu1 = $(this).parents('.cat_sublist').find('.main_menu').html();
                                    sessionStorage.setItem('menu3',menu3);
                                    sessionStorage.setItem('menu2',menu2);
                                    sessionStorage.setItem('menu1',menu1);
                                    sessionStorage.setItem('level',3);
                                    window.location.reload();
                                });
                            }
                        }
                    });
                    var id4 = $('.assortment4').find('li span').html();
                    $.ajax({
                        type: 'get',
                        url: api + '/api/cate/'+id4,
                        dataType: 'json',
                        success: function (m) {
                            //console.log(m);
                            if(m.status ==200){
                                var assortment4=m.data;
                                var html1=template('tpl-assortment4-list-info',assortment4);
                                document.getElementById('assortment4-list-info').innerHTML=html1;
                                $('.cat_sublist').eq(4).find('h3').click(function () {
                                    var cate_id = $(this).find('span').html();
                                    sessionStorage.setItem('cate_id',cate_id);
                                    var menu2 =  $(this).find('a').html();
                                    var menu1 = $(this).parents('.cat_sublist').find('.main_menu').html();
                                    sessionStorage.setItem('menu3','');
                                    sessionStorage.setItem('menu2',menu2);
                                    sessionStorage.setItem('menu1',menu1);
                                    sessionStorage.setItem('level',2);
                                    window.location.reload();
                                });
                                $('.cat_sublist').eq(4).find('ul li').click(function () {
                                    var cate_id = $(this).find('span').html();
                                    sessionStorage.setItem('cate_id',cate_id);
                                    var menu3 = $(this).find('a').html();
                                    var menu2 = $(this).parents('.fore_list').find('h3 a').html();
                                    var menu1 = $(this).parents('.cat_sublist').find('.main_menu').html();
                                    sessionStorage.setItem('menu3',menu3);
                                    sessionStorage.setItem('menu2',menu2);
                                    sessionStorage.setItem('menu1',menu1);
                                    sessionStorage.setItem('level',3);
                                    window.location.reload();
                                });
                            }
                        }
                    });
                    var id5 = $('.assortment5').find('li span').html();
                    $.ajax({
                        type: 'get',
                        url: api + '/api/cate/'+id5,
                        dataType: 'json',
                        success: function (m) {
                            //console.log(m);
                            if(m.status ==200){
                                var assortment5=m.data;
                                var html1=template('tpl-assortment5-list-info',assortment5);
                                document.getElementById('assortment5-list-info').innerHTML=html1;
                                $('.cat_sublist').eq(5).find('h3').click(function () {
                                    var cate_id = $(this).find('span').html();
                                    sessionStorage.setItem('cate_id',cate_id);
                                    var menu2 =  $(this).find('a').html();
                                    var menu1 = $(this).parents('.cat_sublist').find('.main_menu').html();
                                    sessionStorage.setItem('menu3','');
                                    sessionStorage.setItem('menu2',menu2);
                                    sessionStorage.setItem('menu1',menu1);
                                    sessionStorage.setItem('level',2);
                                    window.location.reload();
                                });
                                $('.cat_sublist').eq(5).find('ul li').click(function () {
                                    var cate_id = $(this).find('span').html();
                                    sessionStorage.setItem('cate_id',cate_id);
                                    var menu3 = $(this).find('a').html();
                                    var menu2 = $(this).parents('.fore_list').find('h3 a').html();
                                    var menu1 = $(this).parents('.cat_sublist').find('.main_menu').html();
                                    sessionStorage.setItem('menu3',menu3);
                                    sessionStorage.setItem('menu2',menu2);
                                    sessionStorage.setItem('menu1',menu1);
                                    sessionStorage.setItem('level',3);
                                    window.location.reload();
                                });
                            }
                        }
                    });
                }
            }
        });

        var cateId =sessionStorage.getItem('cate_id');
        var level = sessionStorage.getItem('level');

        var sskeyword =sessionStorage.getItem('sskeyword');
        //分页
        function getUrlParam(key) {
            // 获取参数
            var url = window.location.search;
            // 正则筛选地址栏
            var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
            // 匹配目标参数
            var result = url.substr(1).match(reg);
            //返回参数值
            return result ? decodeURIComponent(result[2]) : null;
        }

        function searchFilter(pageindex){
            var pageNo = getUrlParam('pageIndex');
            if (!pageNo) {
                pageNo = pageindex;
            }
            if(sskeyword && sskeyword !=''){
                url = api + '/w/course?order=2&direction=asc&name='+sskeyword +'&page='+pageNo;
                $('.video_content ul li:nth-of-type(4)').hide();
                $('.video_content ul li:nth-of-type(3)').hide();
                $('.video_content ul li:nth-of-type(2)').find('a').html(sskeyword);
            }else{
                if(!cateId ||cateId == ''){
                    url = api + '/w/course?page='+pageNo;
                    $('.video_content ul li:nth-of-type(4)').hide();
                    $('.video_content ul li:nth-of-type(3)').hide();
                    $('.video_content ul li:nth-of-type(2)').hide();
                }else if(cateId != ''& level == 3){
                    var menu1 =sessionStorage.getItem('menu1');
                    var menu2 =sessionStorage.getItem('menu2');
                    var menu3 =sessionStorage.getItem('menu3');
                    $('.video_content ul li:nth-of-type(4)').find('a').html(menu3);
                    $('.video_content ul li:nth-of-type(3)').find('a').html(menu2);
                    $('.video_content ul li:nth-of-type(2)').find('a').html(menu1);
                    url = api + '/w/course?order=2&direction=asc&cate_id='+cateId +'&page='+pageNo;
                }else if(cateId != ''& level == 2){
                    var menu1 =sessionStorage.getItem('menu1');
                    var menu2 =sessionStorage.getItem('menu2');
                    var menu3 =sessionStorage.getItem('menu3');
                    $('.video_content ul li:nth-of-type(4)').find('a').html(menu3);
                    $('.video_content ul li:nth-of-type(3)').find('a').html(menu2);
                    $('.video_content ul li:nth-of-type(2)').find('a').html(menu1);
                    $('.video_content ul li:nth-of-type(4)').hide();
                    url = api + '/w/course?order=2&direction=asc&cate_id='+cateId +'&page='+pageNo+'&level='+level;
                }
            }

            $.ajax({
                url: url ,
                type:'get',
                dataType:'json',
                xhrFields: {
                    withCredentials: true
                },
                crossDomain: true,
                success:function(re){
                   // console.log(re);
                    if(re.status ==200){
                        var courses=re.data;
                        for(var i=0;i<courses.length;i++){
                            var date = new Date(courses[i].created_at);
                            var time1 = date.getTime();
                            //console.log(time1);
                            function timestampToTime(timestamp) {
                                var date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
                                Y = date.getFullYear() + '-';
                                M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
                                D = date.getDate() + ' ';
                                courses[i].created_at = Y+M+D;
                            }
                            timestampToTime(time1);
                        }
                        var html1=template('tpl-video_courses-list-info',courses);
                        document.getElementById('video_courses-list-info').innerHTML=html1;
                        if(re.data==''){
                            $('#kkpager').hide();
                        }
                        // var tot = Math.ceil(re.total/re.per_page);
                        //生成分页
                        kkpager.generPageHtml({
                            pno: pageNo,
                            //总页码
                            total : re.last_page,
                            //总数据条数
                            totalRecords : re.total,
                            mode : 'click',
                            click : function(n){
                                this.selectPage(pageNo);
                                searchPage(n);
                                return false;
                            }
                        },true);
                    }
                }
            });
        }
        //init
        $(function () {
            searchFilter(1)
        });
        //ajax翻页
        function searchPage(n) {
            searchFilter(n);
        }
    });
});