/**
 * Created by Administrator on 2018/3/21.
 */
/**
 * 网站公用js
 */
require(['../common/common'],function(c){
    require(['jquery','global','jquerysticky','jquerymovebg','layu'],function($,api){
        /**
         * 公用效果
         */
        var layer = layui.layer;
        var api ="https://vedio.jiudingfanyi.com";
        // var api ="http://192.168.1.145";
        /*导航*/
        var user_id = sessionStorage.getItem('user_id');
        var user_name = sessionStorage.getItem('user_name');
        var user_avatar = sessionStorage.getItem('user_avatar');
        var csrf_token = sessionStorage.getItem('csrf_token');

            /*导航置顶*/
            $(".jd_head").sticky({ topSpacing: 0 });

            $(".nav").movebg({
                width:88/*滑块的大小*/,
                extra:40/*额外反弹的距离*/,
                speed:300/*滑块移动的速度*/,
                rebound_speed:400/*滑块反弹的速度*/
            });
            $(".nav ul li").click(function(){
                var index=$(".nav ul li").index(this)
                $(this).addClass("cure").siblings().removeClass("cure");
            });

            /*d登录注册二维码*/
            $(".login").click(function(){
                var current_url = window.location.href;
                sessionStorage.setItem('current_url',current_url);
                window.location.href='https://open.weixin.qq.com/connect/qrconnect?appid=wx7898df574edbcfd1&redirect_uri=http%3a%2f%2fwww.zhongmeiyixue.com&response_type=code&scope=snsapi_login&state=STATE&connect_redirect=1#wechat_redirect';
                //微信号登录
            });
            $(".logon").click(function(){
                var current_url = window.location.href;
                sessionStorage.setItem('current_url',current_url);
                //微信号注册
                window.location.href='https://open.weixin.qq.com/connect/qrconnect?appid=wx7898df574edbcfd1&redirect_uri=http%3a%2f%2fwww.zhongmeiyixue.com&response_type=code&scope=snsapi_login&state=STATE&connect_redirect=1#wechat_redirect';
            });

            //隐藏登录注册，显示用户信息
            if(!user_id || user_id ==''){
                $('.state').find('input').show();
                $('.state').find('.userinfo').hide();
            }
            if(!user_name || user_name ==''){
                $('.state').find('input').show();
                $('.state').find('.userinfo').hide();
            }
            if(!user_avatar || user_avatar ==''){
                $('.state').find('input').show();
                $('.state').find('.userinfo').hide();
            }
            if(!csrf_token || csrf_token ==''){
                $('.state').find('input').show();
                $('.state').find('.userinfo').hide();
            }

            if(user_id && user_name && user_avatar && csrf_token){
                if(user_id !='' && user_name!='' && user_avatar!=''&& csrf_token!=''){
                    var now_user_name = $('.userinfo p').find('em').html();
                    var now_user_avatar = $('.userinfo p').find('img').attr('src');
                    if(now_user_name !='' && now_user_avatar != ''){
                        return false;
                    }else{
                        $('.state').find('.userinfo p').eq(0).find('img').attr('src',user_avatar);
                        $('.state').find('.userinfo p').eq(0).find('em').html(user_name);
                    }
                    $('.state').find('input').hide();
                    $('.state').find('.userinfo').show();
                }else{
                    $('.state').find('input').show();
                    $('.state').find('.userinfo').hide();
                    $('.state').find('.userinfo p').eq(0).find('img').removeAttr('src');
                    $('.state').find('.userinfo p').eq(0).find('em').html('');
                }
            }else{
                $('.state').find('input').show();
                $('.state').find('.userinfo').hide();
                $('.state').find('.userinfo p').eq(0).find('img').removeAttr('src');
                $('.state').find('.userinfo p').eq(0).find('em').html('');
            }

            $('.quit_btn').click(function () {
                $.ajax({
                    url: api + "/w/logout",
                    type: "get",
                    //下面几行是jsoup，如果去掉下面几行的注释，后端对应的返回结果也要去掉注释
                    dataType: 'json',
                    xhrFields: {
                        withCredentials: true
                    },
                    crossDomain: true,
                    success: function (h) {
                        //console.log(h)
                        if(h.status ==200){
                            $('.state').find('input').show();
                            $('.state').find('.userinfo').hide();
                            $('.state').find('.userinfo p').eq(0).find('img').removeAttr('src');
                            $('.state').find('.userinfo p').eq(0).find('em').html('');
                            sessionStorage.setItem('user_id','');
                            sessionStorage.setItem('user_name','');
                            sessionStorage.setItem('user_avatar','');
                            sessionStorage.setItem('csrf_token','');
                            window.location.reload();
                        }
                    }
                });
            });
            //口语课程管理入口
            $(".course_manage").click(function(){
                $.ajax({
                    type: 'get',
                    url: api + '/api/course/all',
                    dataType: 'json',
                    success: function (m) {
                        //console.log(m);

                    }
                });
                $(".bg").fadeIn(200);
                $(".prompt_info").fadeIn(400);
            });
            $(".close_img").click(function(){
                $(".bg").fadeOut(800);
                $('.prompt_info').fadeOut(800);
                $('.payment_code').fadeOut(800);
            });

            $('.search_btn').click(function () {
                var sskeyword = $('.search_box').val();
                if(sskeyword ==''){
                    layer.msg('搜索框未输入内容');
                    return false;
                }else{
                    sessionStorage.setItem('sskeyword',sskeyword);
                    $(this).attr('href','index.html');
                }
            });
            $('.search_box').bind('keypress', function (event) {
                if (event.keyCode == "13") {
                    var sskeyword = $('.search_box').val();
                    if(sskeyword ==''){
                        layer.msg('搜索框未输入内容');
                        return false;
                    }else{
                        sessionStorage.setItem('sskeyword',sskeyword);
                        window.location.href='http://www.zhongmeiyixue.com/index.html';
                    }
                }
            });
            $('.jd_head .nav ul').find('a').click(function () {
                sessionStorage.setItem('sskeyword','');
            });
            $(document).on('click','.cat_sublist h3 a',function(){
                sessionStorage.setItem('sskeyword','');
            });
            $(document).on('click','.cat_sublist li a',function(){
                sessionStorage.setItem('sskeyword','');
            });
    });
});