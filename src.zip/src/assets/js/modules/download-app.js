require(['../common/common'],function(c){
    require(['jquery','base','global'],function($,api){

        /**
         * 数据渲染
         */
        var api ="https://vedio.jiudingfanyi.com";

    });
});