require(['../common/common'],function(c){
    require(['jquery','base','global','layu'],function($,api){

        /**
         * 数据渲染
         */
        /*选项卡*/

        var api ="https://vedio.jiudingfanyi.com";
        var $ = layui.jquery
            ,element = layui.element; //Tab的切换功能，切换事件监听等，需要依赖element模块
        var layer = layui.layer;
        //监听导航点击
        element.on('nav(demo)', function(elem){
            //console.log(elem)
            layer.msg(elem.text());
        });



    });
});