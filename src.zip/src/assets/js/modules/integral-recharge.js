require(['../common/common'],function(c){
    require(['jquery','base','global','layu'],function($,api){

        /**
         * 数据渲染
         */
        /*选项卡*/
        var layer = layui.layer;
        var api ="https://vedio.jiudingfanyi.com";
        var user_id = sessionStorage.getItem('user_id');
        var csrf_token = sessionStorage.getItem('csrf_token');
        $(function(){
            $(".integral_recharge_content_left ul li").click(function(){
                var index=$(".integral_recharge_content_left ul li").index(this)
                $(this).addClass("opt").siblings().removeClass("opt")
                $(".integral_recharge_content_left div").eq(index).addClass("select").siblings().removeClass("select")
            })
        });
        $('.integral_recharge_content_left .recharge_page ol').find('li').click(function () {
            $(this).parents('ol').find('li').removeClass('align_selection');
            $(this).addClass('align_selection');
        });
        if(user_id && user_id !=''){
            $.ajax({
                type: 'get',
                url: api + '/w/user/'+user_id,
                dataType: 'json',
                xhrFields: {
                    withCredentials: true
                },
                crossDomain: true,
                success: function (x) {
                    //console.log(x);
                    if(x.status==200){
                        var now_point = x.data.point;
                        $('.integral_recharge_content_left h4').find('em').html(now_point);
                    }
                }
            });

            function getUrlParam(key) {
                // 获取参数
                var url = window.location.search;
                // 正则筛选地址栏
                var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
                // 匹配目标参数
                var result = url.substr(1).match(reg);
                //返回参数值
                return result ? decodeURIComponent(result[2]) : null;
            }

            function searchFilter(pageindex){
                var pageNo = getUrlParam('pageIndex');
                if (!pageNo) {
                    pageNo = pageindex;
                }
                $.ajax({
                    url: api + '/w/user/'+user_id+'/point?page='+pageNo,
                    type:'get',
                    dataType:'json',
                    xhrFields: {
                        withCredentials: true
                    },
                    crossDomain: true,
                    success:function(z){
                       // console.log(z);
                        if(z.status ==200){
                            var integral1=z.data;
                            var html2=template('tpl-integral_record-info',integral1);
                            document.getElementById('integral_record-info').innerHTML=html2;
                            if(z.data==''){
                                $('#kkpager').hide();
                            }
                            //生成分页
                            kkpager.generPageHtml({
                                pno: pageNo,
                                //总页码
                                total : z.last_page,
                                //总数据条数
                                totalRecords : z.total,
                                mode : 'click',
                                click : function(n){
                                    this.selectPage(pageNo);
                                    searchPage(n);
                                    return false;
                                }
                            },true);
                        }
                    }
                });
            }
            //init
            $(function () {
                searchFilter(1)
            });
            //ajax翻页
            function searchPage(n) {
                searchFilter(n);
            }
        }

        $('.payment_btn').click(function () {
            var sum =1;
            $('#qrcode').html('');
            var recharge_po = $('.integral_recharge_content_left .recharge_page ol .align_selection').find('b').html();
            var recharge_point = parseInt(recharge_po);
            if(user_id && user_id !=''){
                $.ajax({
                    type: 'post',
                    url: api + '/w/order',
                    dataType: 'json',
                    data:{
                        type:'native',
                        point:recharge_point
                    },
                    xhrFields: {
                        withCredentials: true
                    },
                    crossDomain: true,
                    headers:{'X-CSRF-TOKEN':csrf_token},
                    success: function (re) {
                       // console.log(re);
                        if(re.status ==200){
                            var er_code=re.code_url[0];//获得微信后台返回的code_url
                            new QRCode($("#qrcode")[0],er_code);//根据code_url生成二维码，并显示
                            $('.payment_code').show();

                            var orderid = re.order.id;
                            //实时刷新时间单位为毫秒
                            var setnow = setInterval(function () {
                                $.ajax({
                                    type: 'get',
                                    url: api + '/w/order/'+orderid,
                                    dataType: 'json',
                                    xhrFields: {
                                        withCredentials: true
                                    },
                                    crossDomain: true,
                                    success: function (m) {
                                        // console.log(m);
                                        if(m.status==200){
                                            if(m.data.status==1){
                                                window.location.href='http://www.zhongmeiyixue.com/integral-recharge.html'
                                                $('.integral_recharge_content_left ul').find('li').removeClass('opt');
                                                $('.integral_recharge_content_left ul').find('li').eq(1).addClass('opt');
                                                $('.integral_recharge_content_left div').eq(0).addClass('record_page');
                                                $('.integral_recharge_content_left div').eq(0).removeClass('select');
                                                $('.integral_recharge_content_left div').eq(0).removeClass('recharge_page');
                                                $('.integral_recharge_content_left div').eq(1).removeClass('record_page');
                                                $('.integral_recharge_content_left div').eq(1).addClass('select');
                                                $('.integral_recharge_content_left div').eq(1).addClass('recharge_page');
                                            }
                                        }
                                    }
                                });
                                sum++;
                                //console.log(sum);
                                if(sum==12){
                                    clearInterval(setnow);
                                    $('.payment_code').fadeOut(800);
                                    layer.alert('由于您长时间未支付，支付框自动关闭，如若支付，请再点击支付按钮');
                                }
                            },5000);
                        }
                    }
                });
            }else{
                layer.msg('您还未登录，请先注册登录');
            }
        })

    });
});

