require(['../common/common'],function(c){
    require(['jquery','base','global','layu'],function($,api){

/**
 * 数据渲染
 */
        var layer = layui.layer;
        var api ="https://vedio.jiudingfanyi.com";
        var user_id = sessionStorage.getItem('user_id');
        var user_name = sessionStorage.getItem('user_name');
        var user_avatar = sessionStorage.getItem('user_avatar');
        var csrf_token = sessionStorage.getItem('csrf_token');
        function GetQueryString(name)
        {
            var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
            var r = window.location.search.substr(1).match(reg);
            if(r!=null)return  unescape(r[2]); return null;
        }

        function statusinfo() {
            layer.confirm('登录后才能提交，请先登录！', {
                btn: ['登录','取消'] //按钮
            }, function(){
                var current_url = window.location.href;
                sessionStorage.setItem('current_url',current_url);
                window.location.href='https://open.weixin.qq.com/connect/qrconnect?appid=wx7898df574edbcfd1&redirect_uri=http%3a%2f%2fwww.zhongmeiyixue.com&response_type=code&scope=snsapi_login&state=STATE&connect_redirect=1#wechat_redirect';
            }, function(){
                // layer.msg('好的', {icon: 1});
            });
        }
        var id = GetQueryString("vid");
        var source;
        $(".drawer_box1").hide();
        $('.course_details_contop_top_info .click_btn').find('span').hide();
        $('.course_details_contop_top_info .click_btn').find('input').hide();

        $.ajax({
            url: api + '/w/videos/'+id,
            type:'get',
            dataType:'json',
            xhrFields: {
                withCredentials: true
            },
            crossDomain: true,
            success:function(r){
                //console.log(r);
                if(r.status==200){
                    $('.course_details_contop_top .video_title h4').eq(0).find('a').html(r.data.title_ch);
                    $('.course_details_contop_top .video_title h4').eq(1).find('a').html(r.data.title_en);
                    source= r.data.address;
                    var course_id = r.data.course;
                    //课程信息
                    $.ajax({
                        url: api + '/w/course/'+course_id,
                        type:'get',
                        dataType:'json',
                        xhrFields: {
                            withCredentials: true
                        },
                        crossDomain: true,
                        success:function(m){
                            //console.log(m);
                            if(m.status==200){
                                var course_title = 'course_page.html?id='+ m.data.id;
                                $('.course_details_contop_top_info').find('p a').attr('href',course_title)
                                $('.course_details_contop_top_info').find('p a').html(m.data.name);
                                $('.course_introduction').find('p').html(m.data.profile);
                                $('.course_details_contop_top_info ul li').eq(0).find('img').attr('src',m.data.cover);
                                $('.course_details_contop_top_info ul li').eq(1).find('span').eq(0).find('em').html(m.data.video_num);
                                $('.course_details_contop_top_info ul li').eq(1).find('span').eq(1).find('em').html(m.data.point);
                            }
                        }
                    });
                    //课程是否购买
                    if(user_id && user_id !=''){
                        $.ajax({
                            url: api + '/w/user/'+user_id+'/purchased/course/'+course_id,
                            type:'get',
                            dataType:'json',
                            xhrFields: {
                                withCredentials: true
                            },
                            crossDomain: true,
                            success:function(re){
                                //console.log(re);
                                if(re.status==200){
                                    $('.course_details_contop_top_info .click_btn').find('span').show();
                                    $('.course_details_contop_top_info .click_btn').find('input').hide();
                                }else{
                                    $('.course_details_contop_top_info .click_btn').find('span').hide();
                                    $('.course_details_contop_top_info .click_btn').find('input').show();
                                }
                            }
                        });
                    }

                    $('.buy_btn').on('click',function () {
                        layer.confirm('您是否确定购买本课程？', {
                            btn: ['确定','取消'] //按钮
                        }, function(){
                            $.ajax({
                                url: api + '/w/course/buy/'+course_id,
                                type:'get',
                                dataType:'json',
                                xhrFields: {
                                    withCredentials: true
                                },
                                crossDomain: true,
                                success:function(m){
                                    //console.log(m);
                                    if(m.status==200){
                                        layer.alert('购买成功');
                                        $('.course_details_contop_top_info .click_btn').find('span').show();
                                        $('.course_details_contop_top_info .click_btn').find('input').hide();
                                    }else{
                                        layer.alert(m.msg);
                                    }
                                }
                            });
                        }, function(){
                            layer.msg('好的', {icon: 1});
                        });
                    })
                    /*视频播放器*/
                    var player = null;

                    $(function(){
                        player = createPlayer(source);
                        player.on('ready',function(){
                            //console.log('ready可以调用播放器的方法了');
                        });

                        player.on('play',function(){
                            //console.log('开始播放(play)');
                        });

                        player.on('pause',function(){
                            //console.log('暂停播放(pause)');
                        });

                        $('.change').on('click',function(){
                            var source = $('.source').val();
                            var playAuth = $('.playauth').val();
                            player = createPlayer(source,playAuth);
                        })

                        $('.submit').on('click',function(){
                            var source = $('.source').val();
                            var playAuth = $('.playauth').val();
                            if(!source)
                            {
                                return;
                            }
                            if(source.indexOf('//')!=-1)
                            {
                                player.loadByUrl(source);
                            }
                            else if(playAuth)
                            {
                                if(player.replayByVidAndPlayAuth)
                                {
                                    player.replayByVidAndPlayAuth(source, playAuth);
                                }
                                else
                                {
                                    player = createPlayer(source,playAuth);
                                }
                            }
                        })
                    });

                    function createPlayer(source, playauth)
                    {
                        if(player)
                        {
                            player.dispose();
                            $('#J_prismPlayer').empty();
                            player = null;
                        }
                        var vid = source;
                        if(!source && !playauth)
                        {
                            source = '';
                            vid = "";
                            playauth = "";
                        }
                        else if(source.indexOf('//')!=-1)
                        {
                            playAuth = "";
                        }
                        else if(playauth)
                        {
                            source = "";
                        }
                        var option = {
                            id: "J_prismPlayer",
                            autoplay: false,
                            isLive:false,
                            playsinline:true,
                            width:"840px",
                            height:"355px",
                            controlBarVisibility:"click",
                            useH5Prism:false, //启用H5播放器
                            useFlashPrism:true,
                            source:source,
                            vid:vid,
                            playauth:playauth,
                            cover:""
                        };
                        return new Aliplayer(option);
                    }


                }
            }
        });

        //获取翻译
        $.ajax({
            url: api + '/api/vedio/sublist?vid='+id,
            type:'get',
            dataType:'json',
            xhrFields: {
                withCredentials: true
            },
            crossDomain: true,
            success:function(d){
                //console.log(d);
                if(d.status==200){
                    var translation=d.data;
                    for(var i=0;i<translation.length;i++){
                        cont_en =translation[i].cont_en.split(/\s+/);
                        translation[i].cont_en2 = cont_en;
                    }
                    var html1=template('tpl-translation_list',translation);
                    document.getElementById('translation_list').innerHTML=html1;

                    /*点单词进行翻译*/
                    $('.word_info').bind("click",function () {
                        $('.drawer_box1 .yinbiao').find('p').html('');
                        $('.drawer_box1 .yinbiao').find('audio').removeAttr('src');
                        $('.drawer_box1 .Chinese').find('div').find('p').html('');
                        var word1 =$(this).text().toLowerCase();
                        var word = word1.replace(/\W+/gi,'');
                        $('.drawer_box1 .English').find('.title').html(word);
                        $.ajax({
                            type: 'get',
                            url: api + '/api/vocab/detail/'+word,
                            dataType: 'json',
                            xhrFields: {
                                withCredentials: true
                            },
                            crossDomain: true,
                            success: function (m) {
                               // console.log(m);
                                if(m.pos ==null){
                                    layer.alert('未查询到释义')
                                    $(".drawer_box1").hide();
                                    return false;
                                }
                                if(Array.isArray(m.ps)){
                                    var ysfy = '英['+m.ps[0]+']';
                                    var msfy = '美['+m.ps[1]+']';
                                    var ysyp = m.pron[0];
                                    var msyp = m.pron[1];
                                    $('.drawer_box1 .yinbiao').eq(0).find('p').html(ysfy);
                                    $('.drawer_box1 .yinbiao').eq(1).find('p').html(msfy);
                                    $('.drawer_box1 .yinbiao').eq(0).find('audio').attr('src',ysyp);
                                    $('.drawer_box1 .yinbiao').eq(1).find('audio').attr('src',msyp);
                                    $('.drawer_box1 .yinbiao').eq(1).find('img').show();
                                }else {
                                    var ysfy = '英['+m.ps+']';
                                    var ysyp = m.pron;
                                    $('.drawer_box1 .yinbiao').eq(0).find('p').html(ysfy);
                                    $('.drawer_box1 .yinbiao').eq(0).find('audio').attr('src',ysyp);
                                    $('.drawer_box1 .yinbiao').eq(1).find('img').hide();
                                }
                                if(Array.isArray(m.pos)){
                                    var cx0 = m.pos[0];
                                    var cx1 = m.pos[1];
                                    var cx2 = m.pos[2];
                                    var sy0 = m.acceptation[0];
                                    var sy1 = m.acceptation[1];
                                    var sy2 = m.acceptation[2];
                                    $('.drawer_box1 .Chinese').find('div').eq(0).find('p').eq(0).html(cx0);
                                    $('.drawer_box1 .Chinese').find('div').eq(0).find('p').eq(1).html(sy0);
                                    $('.drawer_box1 .Chinese').find('div').eq(1).find('p').eq(0).html(cx1);
                                    $('.drawer_box1 .Chinese').find('div').eq(1).find('p').eq(1).html(sy1);
                                    $('.drawer_box1 .Chinese').find('div').eq(2).find('p').eq(0).html(cx2);
                                    $('.drawer_box1 .Chinese').find('div').eq(2).find('p').eq(1).html(sy2);
                                }else{
                                    var cx0 = m.pos;
                                    var sy0 = m.acceptation;
                                    $('.drawer_box1 .Chinese').find('div').eq(0).find('p').eq(0).html(cx0);
                                    $('.drawer_box1 .Chinese').find('div').eq(0).find('p').eq(1).html(sy0);
                                }
                                $.ajax({
                                    type: 'get',
                                    url: api + '/w/voc/exist/'+word,
                                    dataType: 'json',
                                    xhrFields: {
                                        withCredentials: true
                                    },
                                    crossDomain: true,
                                    success: function (n) {
                                      //  console.log(n);
                                        if(n.status ==200){
                                            var vid =n.data.id;
                                            $('.img_hui').hide();
                                            $('.img_yellow').show();
                                            $('.img_yellow').click(function () {
                                                $.ajax({
                                                    type: 'get',
                                                    url: api + '/w/voc/del/'+vid,
                                                    dataType: 'json',
                                                    xhrFields: {
                                                        withCredentials: true
                                                    },
                                                    crossDomain: true,
                                                    success: function (a) {
                                                        //console.log(a);
                                                        if(a.status ==200) {
                                                            $('.img_hui').show();
                                                            $('.img_yellow').hide();
                                                        }
                                                    }
                                                });
                                            })
                                        }else if(n.status ==400){
                                            $('.img_hui').show();
                                            $('.img_yellow').hide();
                                            $('.img_hui').click(function () {
                                                $.ajax({
                                                    type: 'get',
                                                    url: api + '/w/voc/add/'+word,
                                                    dataType: 'json',
                                                    xhrFields: {
                                                        withCredentials: true
                                                    },
                                                    crossDomain: true,
                                                    success: function (a) {
                                                        //console.log(a);
                                                        if(a.status ==200){
                                                            $('.img_hui').hide();
                                                            $('.img_yellow').show();
                                                        }
                                                    }
                                                });
                                            })
                                        }
                                    }
                                });
                                $(".drawer_box1").show();
                            }
                        });
                    });

                    var height = - $(".drawer_box1").height();
                    $(".drawer_box1").css("margin-top",height);
                    $(".close_img").click(function(){
                        $(".drawer_box1").hide();
                    });


                    //获取右侧翻译列表
                    $('.chinese_meaning').bind('click',function () {
                        if(!user_id || user_id =='') {
                            layer.msg('注册登录后才可以翻译！');
                            return false;
                        }
                        var now_time= $(this).find('b').html();
                        $.ajax({
                            type: 'get',
                            url: api + '/w/videos/'+id+'/subtitle/time/'+now_time,
                            dataType: 'json',
                            xhrFields: {
                                withCredentials: true
                            },
                            crossDomain: true,
                            success: function (z) {
                                //console.log(z);
                                if(z.status ==200){
                                    var meaning=z.data;
                                    var html3=template('tpl-translation_chinese_meaning',meaning);
                                    document.getElementById('translation_chinese_meaning').innerHTML=html3;
                                    var now_cont_en = z.data[0].cont_en;
                                    $('#en_info').val(now_cont_en);
                                    var now_cont_ch = z.data[0].cont_ch;
                                    if(now_cont_ch ==null){
                                        $('#ch_info').val('');
                                    }else{
                                        $('#ch_info').val(now_cont_ch);
                                    }
                                    for(var i= 0;i<meaning.length;i++){
                                        if(meaning[i].liked ==1){
                                            $('.laud_btn_no').hide();
                                            $('.laud_btn_yes').show();
                                        }else{
                                            $('.laud_btn_no').show();
                                            $('.laud_btn_yes').hide();
                                        }
                                    }
                                    //点赞
                                    $('.laud_btn_no').click(function () {
                                        var laud = $(this);
                                        var sid =laud.parent('i').find('b').html();
                                        var laudnum = laud.parent('i').find('span').html();
                                        //console.log(sid)
                                        $.ajax({
                                            type: 'get',
                                            url: api + '/w/video/'+id+'/subtitle/'+sid+'/like',
                                            dataType: 'json',
                                            xhrFields: {
                                                withCredentials: true
                                            },
                                            crossDomain: true,
                                            success: function (v) {
                                                //console.log(v);
                                                if(v.status ==200){
                                                    var laudn = parseInt(laudnum)+1;
                                                    laud.parent('i').find('.laud_btn_no').hide();
                                                    laud.parent('i').find('.laud_btn_yes').show();
                                                    laud.parent('i').find('span').html(laudn);
                                                }
                                            }
                                        });
                                    });
                                    //取消点赞
                                    $('.laud_btn_yes').click(function () {
                                        var laud = $(this);
                                        var sid =laud.parent('i').find('b').html();
                                        var laudnum = laud.parent('i').find('span').html();
                                        //console.log(sid)
                                        $.ajax({
                                            type: 'get',
                                            url: api + '/w/video/'+id+'/subtitle/'+sid+'/like',
                                            dataType: 'json',
                                            xhrFields: {
                                                withCredentials: true
                                            },
                                            crossDomain: true,
                                            success: function (v) {
                                                //console.log(v);
                                                if(v.status ==200){
                                                    var laudn = parseInt(laudnum)-1;
                                                    laud.parent('i').find('.laud_btn_no').show();
                                                    laud.parent('i').find('.laud_btn_yes').hide();
                                                    laud.parent('i').find('span').html(laudn);
                                                }
                                            }
                                        });
                                    })
                                }
                            }
                        });
                    });

                    var noo_cont_ch =$('.assess_info').eq(0).find('p').eq(1).html();
                    //提交翻译按钮
                    $('.submit_btn').click(function () {
                        if(!user_id){
                            statusinfo();
                            return false;
                        }else if(!user_name){
                            statusinfo();
                            return false;
                        }else if(!user_avatar){
                            statusinfo();
                            return false;
                        }else if(!csrf_token){
                            statusinfo();
                            return false;
                        }
                        if(user_id ==''){
                            statusinfo();
                            return false;
                        }else if(user_name ==''){
                            statusinfo();
                            return false;
                        }else if(user_avatar ==''){
                            statusinfo();
                            return false;
                        }else if(csrf_token ==''){
                            statusinfo();
                            return false;
                        }

                        var now_time = $('.assess_info').eq(0).find('strong').html();
                        var ssid = $('.assess_info').eq(0).find('b').html();
                        var new_cont_en = $('#en_info').val();
                        var new_cont_ch = $('#ch_info').val();
                        if(new_cont_en == ''){
                            layer.alert('听写部分不能为空！');
                            return false;
                        }
                        if(noo_cont_ch == new_cont_ch){
                            layer.alert('翻译部分没有更改！');
                            return false;
                        }
                        if(new_cont_en ==''){
                            layer.alert('听写部分不能为空！');
                            return false;
                        }
                        if(new_cont_ch ==''){
                            layer.alert('翻译部分不能为空！');
                            return false;
                        }
                        if(noo_cont_ch ==null){
                            //增加翻译
                            $.ajax({
                                type: 'post',
                                url: api + '/w/video/'+id+'/subtitle/'+now_time+'/add',
                                data:{
                                    cont_en:new_cont_en,
                                    cont_ch:new_cont_ch
                                },
                                dataType: 'json',
                                headers:{'X-CSRF-TOKEN':csrf_token},
                                xhrFields: {
                                    withCredentials: true
                                },
                                crossDomain: true,
                                success: function (x) {
                                    //console.log(x);
                                    if(x.status ==200){
                                        layer.alert('提交成功');
                                    }else{
                                        layer.msg(x.msg);
                                    }
                                }
                            });
                        }else{
                            //编辑翻译
                            $.ajax({
                                type: 'post',
                                url: api + '/w/video/'+id+'/subtitle/'+now_time+'/'+ssid,
                                data:{
                                    cont_en:new_cont_en,
                                    cont_ch:new_cont_ch
                                },
                                dataType: 'json',
                                headers:{'X-CSRF-TOKEN':csrf_token},
                                xhrFields: {
                                    withCredentials: true
                                },
                                crossDomain: true,
                                success: function (x) {
                                    //console.log(x);
                                    if(x.status ==200){
                                        layer.alert('编辑成功')
                                    }else{
                                        layer.msg(x.msg);
                                    }
                                }
                            });
                        }
                    })


                }
            }
        });

    });
});