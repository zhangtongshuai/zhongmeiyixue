requirejs.config({
    paths:{
        'jquery':'../lib/jquery-1.7.2.min',
    	'template':'../lib/template',
        'base':'../modules/base',
        'global':'../modules/global',
        'layui':'../lib/layui/layui',
        'layu':'../lib/layui/layui.all',
        'laydate':'../lib/laydate/laydate',
        'jquerymovebg':'../lib/jquery.movebg',
        'kkpager':'../lib/kkpager',
        'shutter':'../lib/shutter',
        'velocity':'../lib/velocity',
        'jquerysticky':'../lib/jquery.sticky',
        'qrcode':'../lib/qrcode.min',
        'aliplayer':'https://g.alicdn.com/de/prismplayer/2.6.0/aliplayer-min',
        'wxLogin':'http://res.wx.qq.com/connect/zh_CN/htmledition/js/wxLogin'
    },
    shim: {
    	"slider": {
    		deps: ['jquery']
    	}
    }
});